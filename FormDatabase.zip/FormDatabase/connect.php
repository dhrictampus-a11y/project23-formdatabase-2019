<?php
 // CREATE DATABASE CONNECTION CHANGE THE TEST INTO RESERVATION AFTER MAKING IT ON PHPMYADMIN
  $db = mysqli_connect('localhost', 'root', '', 'test') or die("Connect failed". mysli_error());
 // SELECT FORM FIELD DATA
   if(isset($_POST['submit'])){
  	 $date = mysqli_real_escape_string($db, $_POST['date']);
  	 $time = mysqli_real_escape_string($db, $_POST['time']);
  	 $fullname = mysqli_real_escape_string($db, $_POST['fullname']);
  	 $email = mysqli_real_escape_string($db, $_POST['email']);
  	 $phone = mysqli_real_escape_string($db, $_POST['phone']);
  	 $tablenumbers = mysqli_real_escape_string($db, $_POST['tablenumbers']);
  	 $mealplan = mysqli_real_escape_string($db, $_POST['mealplan']);
}
 

?>